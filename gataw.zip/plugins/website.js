let handler = async m => {

let krtu = `web`
m.reply(`
> https://api.botcahx.live
> https://tiodevhost.my.id

`.trim()) 
}
handler.command = /^(web)$/i

module.exports = handler
